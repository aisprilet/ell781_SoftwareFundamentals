import java.util.Scanner;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;

class ListADT<T> {
    private List<T> list;
    private int current;

    ListADT() {
        list = new ArrayList<>();
        current = -1;
    }

    void MAKENULL() {
        list.clear();
        current = -1;
    }

    T FIRST() {
        if (!list.isEmpty()) {
            current = 0;
            return list.get(current);
        }
        return null;
    }

    T NEXT() {
        if (current >= 0 && current < list.size() - 1) {
            current++;
            return list.get(current);
        }
        return null;
    }

    void INSERT(T value) {
        list.add(value);
    }

    void display() {
        for (T value : list) {
            System.out.print(value + " ");
        }
        System.out.println();
    }
}

class GraphADT<T> {
    private HashMap<T, List<T>> adjacencyList;

    GraphADT() {
        adjacencyList = new HashMap<>();
    }

    void addVertex(T vertex) {
        adjacencyList.put(vertex, new ArrayList<>());
    }

    void addEdge(T vertex1, T vertex2) {
        adjacencyList.get(vertex1).add(vertex2);
        adjacencyList.get(vertex2).add(vertex1);
    }

    List<T> getNeighbors(T vertex) {
        return adjacencyList.get(vertex);
    }
}

public class TournamentSchedule {

    public static int num_of_teams;
    public static int num_of_match_pairs;
    public static int max_matches_per_day;

    public static void generateMatchPairs(int n, int[][] matchPairs) {
        int matchIndex = 0;
        for (int i = 1; i <= n; i++) {
            for (int j = i + 1; j <= n; j++) {
                matchPairs[matchIndex][0] = i;
                matchPairs[matchIndex][1] = j;
                matchIndex++;
            }
        }
        int returnFixtureIndex = matchIndex;
        for (int i = 0; i < matchIndex; i++) {
            matchPairs[returnFixtureIndex][0] = matchPairs[i][1];
            matchPairs[returnFixtureIndex][1] = matchPairs[i][0];
            returnFixtureIndex++;
        }
    }

    public static void createAdjacencyMatrix(GraphADT<Integer> graph, int[][] matchPairs, int n, int[][] adjacencyMatrix) {
        for (int i = 0; i < num_of_match_pairs; ++i) {
            for (int j = 0; j < num_of_match_pairs; ++j) {
                int home1 = matchPairs[i][0];
                int away1 = matchPairs[i][1];
                int homeMaxMatchPairsPerDay = matchPairs[j][0];
                int awayMaxMatchPairsPerDay = matchPairs[j][1];

                if (home1 == homeMaxMatchPairsPerDay || home1 == awayMaxMatchPairsPerDay ||
                        away1 == homeMaxMatchPairsPerDay || away1 == awayMaxMatchPairsPerDay) {
                    graph.addEdge(i, j);
                    adjacencyMatrix[i][j] = 1;
                } else {
                    adjacencyMatrix[i][j] = 0;
                }
            }
        }
        for (int i = 0; i < num_of_match_pairs; ++i) {
            for (int j = 0; j < num_of_match_pairs; ++j) {
                if (i == j) {
                    adjacencyMatrix[i][i] = 0;
                }
            }
        }
    }

    public static int greedyGraphColoring(int[][] adjacencyMatrix, int numMatchPairs, int[] colors) {
        int maxColor = 0;
        for (int match = 0; match < numMatchPairs; match++) {
            boolean[] available = new boolean[num_of_match_pairs];
            for (int i = 0; i <= maxColor; i++) {
                available[i] = true;
            }
            for (int adjMatch = 0; adjMatch < numMatchPairs; adjMatch++) {
                if (adjacencyMatrix[match][adjMatch] == 1 && colors[adjMatch] != -1) {
                    available[colors[adjMatch]] = false;
                }
            }
            int color;
            for (color = 0; color <= maxColor; color++) {
                if (available[color]) {
                    break;
                }
            }
            colors[match] = color;
            if (color > maxColor) {
                maxColor = color;
            }
        }
        return maxColor + 1;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of teams: ");
        num_of_teams = scanner.nextInt();
        num_of_match_pairs = num_of_teams * (num_of_teams - 1);
        max_matches_per_day = num_of_teams / 2;

        if (num_of_teams == 1) {
            System.out.println("Minimum 2 teams are required to schedule a match.");
            scanner.close();
            return;
        }

        int[][] matchPairs = new int[num_of_match_pairs][2];
        GraphADT<Integer> cricketGraph = new GraphADT<>();

        for (int i = 0; i < num_of_match_pairs; i++) {
            cricketGraph.addVertex(i);
        }

        generateMatchPairs(num_of_teams, matchPairs);
        int[][] adjacencyMatrix = new int[num_of_match_pairs][num_of_match_pairs];

        createAdjacencyMatrix(cricketGraph, matchPairs, num_of_teams, adjacencyMatrix);

        int[] colors = new int[num_of_match_pairs];
        for (int i = 0; i < num_of_match_pairs; i++) {
            colors[i] = -1;
        }

        int minColors = greedyGraphColoring(adjacencyMatrix, num_of_match_pairs, colors);

        System.out.println("Minimum Number of colors Required: " + minColors);
        System.out.println("Minimum Number of Days Required: " + ((2 * minColors) - 1));

        // Use the List ADT to store the schedule
        ListADT<String>[] schedule = new ListADT[2 * minColors - 1];
        for (int i = 0; i < schedule.length; i++) {
            schedule[i] = new ListADT<>();
        }

        for (int day = 0; day < (minColors * 2) - 1; day++) {
            ListADT<String> daySchedule = schedule[day];
            daySchedule.MAKENULL();
            if (day % 2 == 0) {
                
                daySchedule.INSERT("Day " + (day + 1) + ":");
                for (int match = 0; match < num_of_match_pairs; match++) {
                    if (colors[match] == day / 2) {
                        daySchedule.INSERT("(" + matchPairs[match][0] + " " + matchPairs[match][1] + ")");
                    }
                }
            } else {
                daySchedule.INSERT("Day " + (day + 1) + ":");
            }
        }

        System.out.println("Schedule for the Tournament:");
        for (int day = 0; day < (minColors * 2) - 1; day++) {
            schedule[day].display();
        }

        scanner.close();
    }
}
